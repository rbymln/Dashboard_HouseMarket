from flask import Flask,render_template 
import plotly
import plotly.graph_objects as go
import chart_studio.plotly as csp
import json



app = Flask(__name__)


# @app.route("/") #home
# def home():
#     return "Hello Jakarta"

@app.route("/")
def home():
    return render_template("home.html")

# @app.route("/about")
# def about():
#     return "Belajar Data Science"

@app.route("/klasemen",methods=['POST', 'GET'])
def classmain():
    return render_template("html_exercise_robby.html")

@app.route("/about",methods=['POST', 'GET'])
def about():
    return render_template("about.html")

@app.route("/visualisasi",methods=['POST', 'GET'])
def plot():
    plot = go.Scatter(
        x = [1,2,3,4,5,6,7,8,9],
        y = [7,8,9,3,6,4,5,6,9]
    )
    graphJSON = json.dumps(
        [plot], cls = plotly.utils.PlotlyJSONEncoder
    )
    return render_template('plot.html', plot=graphJSON)



if __name__ == "__main__":
    app.run(debug=True)